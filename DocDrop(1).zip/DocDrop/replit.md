# Overview

HoneyCoin is a blockchain-based platform that creates the world's first honey-backed stablecoin (HNYC). The platform connects verified beekeepers with investors and consumers, enabling direct investment in bee farms while providing a traceable, redeemable honey-backed token. The system features a comprehensive supply chain tracking mechanism with GPS verification, NFC tagging, and smart contract integration for transparent honey production and trading.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom color variables and responsive design
- **State Management**: TanStack Query for server state, React Context for global state
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API endpoints with standardized error handling
- **Session Management**: PostgreSQL-based session storage with connect-pg-simple

## Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle Kit for migrations and schema updates
- **Data Validation**: Zod schemas shared between client and server
- **Storage Interface**: Abstract storage layer with concrete database implementation

## Core Data Models
- **Users**: Wallet-based authentication with consumer/beekeeper roles
- **Beekeepers**: Verified producers with GPS coordinates and lot numbers
- **Hives**: Individual production units with capacity tracking
- **Honey Inventory**: Tracked by weight, grade, and harvest date with NFC integration
- **Investments**: User funding of beekeeping operations
- **Redemptions**: HNYC token redemption for physical honey

## Authentication and Authorization
- **Wallet Integration**: Coinbase Developer Platform integration for Web3 authentication
- **Session Management**: Persistent sessions with PostgreSQL storage
- **Role-Based Access**: Consumer and beekeeper user types with different permissions
- **Wallet-Based Identity**: Users identified by Ethereum wallet addresses

## External Dependencies

### Blockchain and Web3
- **Coinbase Developer Platform**: Primary wallet connection and authentication
- **PYUSD Integration**: Stablecoin backing during initial phases
- **Chainlink Oracles**: Future honey price feeds for commodity-backed stability
- **Circle**: USDC integration for liquidity and stability mechanisms

### Database and Hosting
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **WebSocket Support**: Real-time database connections via Neon's WebSocket interface

### Development Tools
- **Replit**: Development environment with integrated deployment
- **Vite**: Frontend build tooling with hot module replacement
- **ESBuild**: Backend bundling for production deployment

### UI and Design
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Inter and Open Sans font families

### Supply Chain Technology
- **GPS Tracking**: Geolocation verification for farm authenticity
- **NFC Integration**: Near-field communication tags for honey container tracking
- **Lot Number System**: Unique identification for supply chain traceability

### Future Integrations
- **Smart Contracts**: Ethereum-based token contracts for HNYC
- **IPFS**: Decentralized storage for certification documents
- **Payment Processing**: Integration with traditional payment systems