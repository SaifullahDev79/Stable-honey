import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertBeekeeperSchema, insertInvestmentSchema, insertRedemptionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByWallet(userData.walletAddress);
      if (existingUser) {
        return res.json(existingUser);
      }
      
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error: error.message });
    }
  });

  app.get("/api/users/wallet/:address", async (req, res) => {
    try {
      const user = await storage.getUserByWallet(req.params.address);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: error.message });
    }
  });

  // Beekeeper routes
  app.post("/api/beekeepers", async (req, res) => {
    try {
      const beekeeperData = insertBeekeeperSchema.parse(req.body);
      const beekeeper = await storage.createBeekeeper(beekeeperData);
      res.json(beekeeper);
    } catch (error) {
      res.status(400).json({ message: "Invalid beekeeper data", error: error.message });
    }
  });

  app.get("/api/beekeepers", async (req, res) => {
    try {
      const beekeepers = await storage.getApprovedBeekeepers();
      res.json(beekeepers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get beekeepers", error: error.message });
    }
  });

  app.get("/api/beekeepers/user/:userId", async (req, res) => {
    try {
      const beekeeper = await storage.getBeekeeperByUserId(req.params.userId);
      if (!beekeeper) {
        return res.status(404).json({ message: "Beekeeper not found" });
      }
      res.json(beekeeper);
    } catch (error) {
      res.status(500).json({ message: "Failed to get beekeeper", error: error.message });
    }
  });

  app.patch("/api/beekeepers/:id/approve", async (req, res) => {
    try {
      await storage.approveBeekeeperApplication(req.params.id);
      res.json({ message: "Beekeeper approved successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to approve beekeeper", error: error.message });
    }
  });

  // Investment routes
  app.post("/api/investments", async (req, res) => {
    try {
      const investmentData = insertInvestmentSchema.parse(req.body);
      const investment = await storage.createInvestment(investmentData);
      res.json(investment);
    } catch (error) {
      res.status(400).json({ message: "Invalid investment data", error: error.message });
    }
  });

  app.get("/api/investments/user/:userId", async (req, res) => {
    try {
      const investments = await storage.getInvestmentsByUser(req.params.userId);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get investments", error: error.message });
    }
  });

  // Redemption routes
  app.post("/api/redemptions", async (req, res) => {
    try {
      const redemptionData = insertRedemptionSchema.parse(req.body);
      const redemption = await storage.createRedemption(redemptionData);
      res.json(redemption);
    } catch (error) {
      res.status(400).json({ message: "Invalid redemption data", error: error.message });
    }
  });

  app.get("/api/redemptions/user/:userId", async (req, res) => {
    try {
      const redemptions = await storage.getRedemptionsByUser(req.params.userId);
      res.json(redemptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get redemptions", error: error.message });
    }
  });

  // Platform stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getPlatformStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get platform stats", error: error.message });
    }
  });

  // NFC verification route
  app.get("/api/nfc/:tagId", async (req, res) => {
    try {
      // Mock NFC verification - in production this would verify actual NFC tags
      const mockNFCData = {
        farmName: "Meadowbrook Apiary",
        lotNumber: "LOT001",
        harvestDate: "Sept 15, 2024",
        hiveNumber: "H-007",
        grade: "Grade A",
        weight: "1.0 lb",
        verified: true
      };
      res.json(mockNFCData);
    } catch (error) {
      res.status(500).json({ message: "Failed to verify NFC tag", error: error.message });
    }
  });

  // Token price endpoint (mock for hackathon)
  app.get("/api/token/price", async (req, res) => {
    try {
      const tokenData = {
        price: 1.00,
        currency: "USDC",
        honeyWeight: "1 lb",
        grade: "Grade A",
        totalSupply: 45200,
        backedReserves: 100
      };
      res.json(tokenData);
    } catch (error) {
      res.status(500).json({ message: "Failed to get token price", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
