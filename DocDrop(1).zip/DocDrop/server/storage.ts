import { 
  users, beekeepers, hives, honeyInventory, investments, tokenTransactions, redemptions,
  type User, type InsertUser, type Beekeeper, type InsertBeekeeper, 
  type Investment, type InsertInvestment, type HoneyInventory, type Hive,
  type Redemption, type InsertRedemption
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Beekeepers
  getBeekeeper(id: string): Promise<Beekeeper | undefined>;
  getBeekeeperByUserId(userId: string): Promise<Beekeeper | undefined>;
  createBeekeeper(beekeeper: InsertBeekeeper): Promise<Beekeeper>;
  getApprovedBeekeepers(): Promise<Beekeeper[]>;
  approveBeekeeperApplication(id: string): Promise<void>;
  
  // Hives
  getHivesByBeekeeper(beekeeperId: string): Promise<Hive[]>;
  createHive(hive: any): Promise<Hive>;
  
  // Inventory
  getInventoryByHive(hiveId: string): Promise<HoneyInventory[]>;
  getAvailableInventory(): Promise<HoneyInventory[]>;
  
  // Investments
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestmentsByUser(userId: string): Promise<Investment[]>;
  
  // Redemptions
  createRedemption(redemption: InsertRedemption): Promise<Redemption>;
  getRedemptionsByUser(userId: string): Promise<Redemption[]>;
  
  // Stats
  getPlatformStats(): Promise<{
    totalFarms: number;
    totalHives: number;
    honeyProduced: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getBeekeeper(id: string): Promise<Beekeeper | undefined> {
    const [beekeeper] = await db.select().from(beekeepers).where(eq(beekeepers.id, id));
    return beekeeper || undefined;
  }

  async getBeekeeperByUserId(userId: string): Promise<Beekeeper | undefined> {
    const [beekeeper] = await db.select().from(beekeepers).where(eq(beekeepers.userId, userId));
    return beekeeper || undefined;
  }

  async createBeekeeper(insertBeekeeper: InsertBeekeeper): Promise<Beekeeper> {
    // Generate unique lot number
    const lotNumber = `LOT${String(Date.now()).slice(-6)}`;
    
    const [beekeeper] = await db.insert(beekeepers).values({
      ...insertBeekeeper,
      lotNumber
    }).returning();
    return beekeeper;
  }

  async getApprovedBeekeepers(): Promise<Beekeeper[]> {
    return db.select().from(beekeepers).where(eq(beekeepers.isApproved, true));
  }

  async approveBeekeeperApplication(id: string): Promise<void> {
    await db.update(beekeepers).set({ isApproved: true }).where(eq(beekeepers.id, id));
  }

  async getHivesByBeekeeper(beekeeperId: string): Promise<Hive[]> {
    return db.select().from(hives).where(eq(hives.beekeeperId, beekeeperId));
  }

  async createHive(insertHive: any): Promise<Hive> {
    const [hive] = await db.insert(hives).values(insertHive).returning();
    return hive;
  }

  async getInventoryByHive(hiveId: string): Promise<HoneyInventory[]> {
    return db.select().from(honeyInventory).where(eq(honeyInventory.hiveId, hiveId));
  }

  async getAvailableInventory(): Promise<HoneyInventory[]> {
    return db.select().from(honeyInventory).where(eq(honeyInventory.isRedeemed, false));
  }

  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const [investment] = await db.insert(investments).values(insertInvestment).returning();
    return investment;
  }

  async getInvestmentsByUser(userId: string): Promise<Investment[]> {
    return db.select().from(investments).where(eq(investments.userId, userId)).orderBy(desc(investments.createdAt));
  }

  async createRedemption(insertRedemption: InsertRedemption): Promise<Redemption> {
    const [redemption] = await db.insert(redemptions).values(insertRedemption).returning();
    return redemption;
  }

  async getRedemptionsByUser(userId: string): Promise<Redemption[]> {
    return db.select().from(redemptions).where(eq(redemptions.userId, userId)).orderBy(desc(redemptions.createdAt));
  }

  async getPlatformStats(): Promise<{ totalFarms: number; totalHives: number; honeyProduced: number; }> {
    const totalFarms = await db.$count(beekeepers, eq(beekeepers.isApproved, true));
    const totalHives = await db.$count(hives, eq(hives.isActive, true));
    
    // Get total honey produced (sum of all inventory weights)
    const inventoryResult = await db.select().from(honeyInventory);
    const honeyProduced = inventoryResult.reduce((total, item) => total + parseFloat(item.weight), 0);

    return {
      totalFarms,
      totalHives,
      honeyProduced: Math.round(honeyProduced)
    };
  }
}

export const storage = new DatabaseStorage();
