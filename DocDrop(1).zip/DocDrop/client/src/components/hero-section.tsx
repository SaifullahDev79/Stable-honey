import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Sprout, PlusCircle } from "lucide-react";

export default function HeroSection() {
  const [investmentAmount, setInvestmentAmount] = useState(100);

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: tokenData } = useQuery({
    queryKey: ["/api/token/price"],
    staleTime: 30 * 1000, // 30 seconds
  });

  return (
    <section className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-honey-50 to-sage-50"></div>
      <div 
        className="absolute inset-0 opacity-20" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="font-inter font-bold text-5xl lg:text-6xl text-gray-800 leading-tight">
                The Sweet Future of 
                <span className="gradient-honey bg-clip-text text-transparent ml-3">
                  Sustainable Finance
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Invest in verified beekeepers, support biodiversity, and earn returns with the world's first honey-backed stablecoin. Every HNYC token is redeemable for real, traceable honey.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="gradient-honey text-white px-8 py-4 text-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
                <Sprout className="mr-2 h-5 w-5" />
                Start Investing
              </Button>
              <Link href="/apply">
                <Button variant="outline" className="border-2 border-sage-500 text-sage-600 px-8 py-4 text-lg hover:bg-sage-50 transition-all">
                  <PlusCircle className="mr-2 h-5 w-5" />
                  Become a Beekeeper
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-honey-600">
                  {stats?.totalFarms || 127}
                </div>
                <div className="text-gray-600">Verified Farms</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-sage-600">
                  {stats?.totalHives || 2340}
                </div>
                <div className="text-gray-600">Active Hives</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-honey-600">
                  {stats?.honeyProduced ? `${stats.honeyProduced / 1000}k` : "45.2k"}
                </div>
                <div className="text-gray-600">lbs Honey</div>
              </div>
            </div>
          </div>

          <div className="relative">
            {/* Token Price Widget */}
            <div className="glass-effect rounded-2xl p-8 shadow-xl">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-inter font-semibold text-2xl text-gray-800">HNYC Token</h3>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-600 font-medium">Live</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-honey-50 rounded-xl p-4">
                    <div className="text-honey-600 font-medium">Current Price</div>
                    <div className="text-2xl font-bold text-honey-700">
                      ${tokenData?.price || "1.00"}
                    </div>
                    <div className="text-sm text-honey-600">= 1 USDC</div>
                  </div>
                  <div className="bg-sage-50 rounded-xl p-4">
                    <div className="text-sage-600 font-medium">Honey Value</div>
                    <div className="text-2xl font-bold text-sage-700">
                      {tokenData?.honeyWeight || "1 lb"}
                    </div>
                    <div className="text-sm text-sage-600">
                      {tokenData?.grade || "Grade A"} Honey
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Total Supply</span>
                    <span className="font-medium">
                      {tokenData?.totalSupply?.toLocaleString() || "45,200"} HNYC
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Backed Reserves</span>
                    <span className="font-medium text-green-600">
                      {tokenData?.backedReserves || 100}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-honey-400 to-sage-400 h-2 rounded-full" 
                      style={{ width: `${tokenData?.backedReserves || 100}%` }}
                    ></div>
                  </div>
                </div>

                <Button className="w-full gradient-sage text-white py-3 hover:shadow-lg transition-all">
                  <i className="fas fa-coins mr-2"></i>
                  Buy HNYC Tokens
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
