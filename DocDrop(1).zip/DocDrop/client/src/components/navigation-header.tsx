import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";
import { useCoinbase } from "@/hooks/use-coinbase";
import { Wallet, User, Menu, X } from "lucide-react";

export default function NavigationHeader() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isConnected } = useWallet();
  const { connectWallet, isConnecting } = useCoinbase();

  const navigation = [
    { name: "Farms", href: "#farms" },
    { name: "Invest", href: "#invest" },
    { name: "Beekeepers", href: "#beekeepers" },
    { name: "About", href: "#about" },
  ];

  const handleConnectWallet = async () => {
    try {
      await connectWallet();
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    }
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 gradient-honey rounded-full flex items-center justify-center">
              <i className="fas fa-layer-group text-white text-lg"></i>
            </div>
            <span className="font-inter font-bold text-xl text-gray-800">HoneyCoin</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-gray-600 hover:text-honey-500 transition-colors"
              >
                {item.name}
              </a>
            ))}
          </div>

          {/* Wallet Connection */}
          <div className="flex items-center space-x-4">
            {!isConnected ? (
              <Button 
                onClick={handleConnectWallet}
                disabled={isConnecting}
                className="gradient-honey text-white hover:shadow-lg transition-all transform hover:-translate-y-0.5"
              >
                <Wallet className="mr-2 h-4 w-4" />
                {isConnecting ? "Connecting..." : "Connect Wallet"}
              </Button>
            ) : (
              <div className="flex items-center space-x-3">
                <Link href="/dashboard">
                  <Button variant="outline" size="sm">
                    Dashboard
                  </Button>
                </Link>
                <div className="flex items-center space-x-3 bg-sage-50 px-4 py-2 rounded-lg">
                  <div className="w-8 h-8 bg-sage-500 rounded-full flex items-center justify-center">
                    <User className="text-white h-4 w-4" />
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-sage-700 font-medium text-sm">
                      {user?.walletAddress?.slice(0, 6)}...{user?.walletAddress?.slice(-4)}
                    </span>
                    <div className="text-sage-600 text-xs">1,250 HNYC</div>
                  </div>
                </div>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6 text-gray-600" />
              ) : (
                <Menu className="h-6 w-6 text-gray-600" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="space-y-2">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="block px-3 py-2 text-gray-600 hover:text-honey-500 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
