import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Sprout, Heart, Anchor, Scale, Layers } from "lucide-react";

export default function TokenomicsSection() {
  const revenueData = [
    { label: "Beekeepers", percentage: 95, color: "honey" },
    { label: "Platform Fee", percentage: 5, color: "gray" }
  ];

  const communityData = [
    { label: "Community", percentage: 70, color: "green" },
    { label: "Platform", percentage: 30, color: "blue" }
  ];

  const stabilityPhases = [
    {
      phase: "Phase 1: USDC Peg",
      description: "1 HNYC = 1 USDC for hackathon simplicity and initial liquidity",
      icon: Anchor,
      color: "honey"
    },
    {
      phase: "Phase 2: Honey Peg",
      description: "Transition to commodity honey pricing via Chainlink oracles",
      icon: Scale,
      color: "sage"
    },
    {
      phase: "Phase 3: Hybrid Model",
      description: "Mixed reserves of honey inventory + USDC liquidity pool",
      icon: Layers,
      color: "blue"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="font-inter font-bold text-4xl text-gray-800">Fair & Transparent Economics</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our tokenomics prioritize fair compensation for beekeepers while ensuring platform sustainability and community development.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Revenue Split */}
          <Card className="bg-gradient-to-br from-honey-50 to-honey-100">
            <CardHeader className="text-center">
              <div className="w-16 h-16 gradient-honey rounded-full flex items-center justify-center mx-auto mb-4">
                <PieChart className="text-white h-8 w-8" />
              </div>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">
                Revenue Split
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Beekeepers</span>
                  <span className="text-3xl font-bold text-honey-600">95%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Platform Fee</span>
                  <span className="text-xl font-bold text-gray-600">5%</span>
                </div>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-4 mt-6">
                <div 
                  className="bg-gradient-to-r from-honey-400 to-honey-600 h-4 rounded-full" 
                  style={{ width: "95%" }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-4">Industry-leading beekeeper compensation</p>
            </CardContent>
          </Card>

          {/* Investment Returns */}
          <Card className="bg-gradient-to-br from-sage-50 to-sage-100">
            <CardHeader className="text-center">
              <div className="w-16 h-16 gradient-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Sprout className="text-white h-8 w-8" />
              </div>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">
                Investment Returns
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div>
                  <div className="text-3xl font-bold text-sage-600">5-20%</div>
                  <div className="text-gray-700">Seasonal Returns</div>
                </div>
                <div>
                  <div className="text-xl font-bold text-gray-700">12 weeks</div>
                  <div className="text-gray-600">Average Season</div>
                </div>
              </div>

              <Card className="bg-white mt-6">
                <CardContent className="pt-4">
                  <div className="text-sm text-gray-600">Early Exit Penalty</div>
                  <div className="text-2xl font-bold text-red-500">20%</div>
                  <div className="text-xs text-gray-500">Before season end</div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* Community Impact */}
          <Card className="bg-gradient-to-br from-blue-50 to-green-100">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-white h-8 w-8" />
              </div>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">
                Community Impact
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Community</span>
                  <span className="text-3xl font-bold text-green-600">70%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Platform</span>
                  <span className="text-xl font-bold text-blue-600">30%</span>
                </div>
              </div>

              <Card className="bg-white mt-6">
                <CardContent className="pt-4">
                  <div className="text-sm text-gray-600">Dedicated to</div>
                  <div className="text-lg font-bold text-green-600">Environmental Projects</div>
                  <div className="text-xs text-gray-500">Local tribe partnerships</div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </div>

        {/* Token Stability Mechanism */}
        <Card className="mt-12 bg-gray-900 text-white">
          <CardHeader>
            <CardTitle className="font-inter font-bold text-2xl text-center text-white">
              Stability Mechanism
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              {stabilityPhases.map((phase, index) => {
                const IconComponent = phase.icon;
                return (
                  <div key={index} className="text-center">
                    <div className={`w-12 h-12 ${
                      phase.color === 'honey' ? 'bg-honey-500' :
                      phase.color === 'sage' ? 'bg-sage-500' :
                      'bg-blue-500'
                    } rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className="text-white h-6 w-6" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2 text-white">{phase.phase}</h4>
                    <p className="text-gray-300 text-sm">{phase.description}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-honey-600">1:1</div>
              <div className="text-gray-600 text-sm">HNYC:USDC Peg</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-sage-600">100%</div>
              <div className="text-gray-600 text-sm">Backed Reserves</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-blue-600">24/7</div>
              <div className="text-gray-600 text-sm">Redemption</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-green-600">0%</div>
              <div className="text-gray-600 text-sm">Mint/Burn Fee</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
