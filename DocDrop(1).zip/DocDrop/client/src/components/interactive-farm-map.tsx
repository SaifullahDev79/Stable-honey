import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Sprout } from "lucide-react";

interface Farm {
  id: string;
  farmName: string;
  firstName: string;
  lastName: string;
  gpsLatitude: string;
  gpsLongitude: string;
  totalHives: number;
  lotNumber: string;
  yearsExperience: number;
}

export default function InteractiveFarmMap() {
  const [selectedFarm, setSelectedFarm] = useState<Farm | null>(null);

  const { data: farms, isLoading } = useQuery({
    queryKey: ["/api/beekeepers"],
  });

  // Convert GPS coordinates to map positions (California region mapping)
  const getMapPosition = (lat: string, lng: string) => {
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    
    // California bounds: roughly 32.5°N to 42°N, -124.4°W to -114.1°W
    const minLat = 32.5, maxLat = 42.0;
    const minLng = -124.4, maxLng = -114.1;
    
    // Convert to percentage positions on the map
    const x = ((longitude - minLng) / (maxLng - minLng)) * 100;
    const y = ((maxLat - latitude) / (maxLat - minLat)) * 100; // Flip Y for map display
    
    return {
      left: `${Math.max(5, Math.min(95, x))}%`,
      top: `${Math.max(5, Math.min(95, y))}%`
    };
  };

  const handleFarmSelect = (farm: Farm) => {
    setSelectedFarm(farm);
  };

  return (
    <section id="farms" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-12">
          <h2 className="font-inter font-bold text-4xl text-gray-800">Verified Farm Network</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our network of verified beekeepers across the region. Each farm is GPS-tracked and assigned a unique Lot# for complete transparency.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map Container */}
          <div className="lg:col-span-2">
            <div className="map-container bg-gradient-to-br from-sage-50 to-honey-50 rounded-2xl p-8 h-96 relative overflow-hidden shadow-lg">
              {/* California Regional Map Background */}
              <div className="absolute inset-0 opacity-20">
                <svg viewBox="0 0 400 600" className="w-full h-full">
                  {/* California state outline */}
                  <path
                    d="M50 50 L50 550 L350 550 L350 400 L320 350 L300 300 L280 250 L250 200 L200 150 L150 100 L100 80 L50 50 Z"
                    fill="url(#californiaGradient)"
                    stroke="#8FBC8F"
                    strokeWidth="2"
                  />
                  <defs>
                    <linearGradient id="californiaGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#F7DC6F" />
                      <stop offset="50%" stopColor="#82E0AA" />
                      <stop offset="100%" stopColor="#85C1E9" />
                    </linearGradient>
                  </defs>
                  {/* Geographic features */}
                  <circle cx="100" cy="120" r="4" fill="#2E86AB" opacity="0.6" />
                  <text x="110" y="125" fontSize="10" fill="#2E86AB" className="font-medium">SF Bay</text>
                  <circle cx="200" cy="400" r="4" fill="#2E86AB" opacity="0.6" />
                  <text x="210" y="405" fontSize="10" fill="#2E86AB" className="font-medium">LA</text>
                  <circle cx="180" cy="300" r="3" fill="#8B4513" opacity="0.6" />
                  <text x="190" y="305" fontSize="9" fill="#8B4513" className="font-medium">Central Valley</text>
                </svg>
              </div>
              
              {/* Farm Markers with Real GPS Coordinates */}
              {farms?.map((farm: Farm) => {
                const position = getMapPosition(farm.gpsLatitude, farm.gpsLongitude);

                return (
                  <div 
                    key={farm.id}
                    className="absolute farm-marker cursor-pointer group z-10"
                    style={{ 
                      top: position.top, 
                      left: position.left,
                      transform: 'translate(-50%, -50%)'
                    }}
                    onClick={() => handleFarmSelect(farm)}
                  >
                    <div className="w-6 h-6 bg-honey-500 rounded-full border-4 border-white shadow-lg relative animate-pulse">
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                    </div>
                    <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-xl p-3 min-w-48 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <div className="font-semibold text-gray-800">{farm.farmName}</div>
                      <div className="text-sm text-gray-600">{farm.lotNumber} • {farm.totalHives} Hives</div>
                      <div className="text-sm text-green-600">GPS: {parseFloat(farm.gpsLatitude).toFixed(4)}, {parseFloat(farm.gpsLongitude).toFixed(4)}</div>
                      <div className="text-sm text-green-600">Production: Active</div>
                    </div>
                  </div>
                );
              })}

              {/* Map Legend */}
              <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg">
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-honey-500 rounded-full"></div>
                    <span>Verified Farm</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Active</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Farm Details Panel */}
          <div className="space-y-6">
            {!selectedFarm ? (
              <Card className="bg-gray-50">
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <MapPin className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Click on a farm marker to view details</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-white shadow-lg border">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <img 
                      src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
                      alt="Beehive with busy worker bees" 
                      className="w-full h-48 object-cover rounded-xl" 
                    />
                    
                    <div>
                      <h3 className="font-inter font-bold text-xl text-gray-800">{selectedFarm.farmName}</h3>
                      <p className="text-gray-600">GPS: {selectedFarm.gpsLatitude}, {selectedFarm.gpsLongitude}</p>
                      <p className="text-sm text-honey-600 font-medium">{selectedFarm.lotNumber}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-honey-50 rounded-lg p-3">
                        <div className="text-honey-600 text-sm">Total Hives</div>
                        <div className="text-xl font-bold text-honey-700">{selectedFarm.totalHives}</div>
                      </div>
                      <div className="bg-sage-50 rounded-lg p-3">
                        <div className="text-sage-600 text-sm">Experience</div>
                        <div className="text-xl font-bold text-sage-700">{selectedFarm.yearsExperience} yrs</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Beekeeper</span>
                        <span className="font-medium">{selectedFarm.firstName} {selectedFarm.lastName}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Experience</span>
                        <span className="font-medium">{selectedFarm.yearsExperience} years</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Certification</span>
                        <span className="text-green-600 font-medium">Organic Certified</span>
                      </div>
                    </div>

                    <Button className="w-full gradient-honey text-white py-3 hover:shadow-lg transition-all">
                      <Sprout className="mr-2 h-4 w-4" />
                      Invest in This Farm
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Farm List */}
            {isLoading ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-4">Loading farms...</div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold text-gray-800 mb-4">All Verified Farms</h3>
                  <div className="space-y-2">
                    {farms?.map((farm: Farm) => (
                      <div 
                        key={farm.id}
                        className="p-3 rounded-lg border cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleFarmSelect(farm)}
                      >
                        <div className="font-medium text-gray-800">{farm.farmName}</div>
                        <div className="text-sm text-gray-600">{farm.lotNumber} • {farm.totalHives} Hives</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
