import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DollarSign, Globe, Shield, CheckSquare } from "lucide-react";

export default function BeekeeperOnboarding() {
  return (
    <section id="beekeepers" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="font-inter font-bold text-4xl text-gray-800">Join Our Beekeeper Network</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Become a verified beekeeper and connect directly with consumers. Earn 95% of sales revenue while we handle the platform and logistics.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Benefits & Requirements */}
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Benefits of Joining</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 gradient-honey rounded-lg flex items-center justify-center flex-shrink-0">
                    <DollarSign className="text-white h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">95% Revenue Share</h4>
                    <p className="text-gray-600">Keep 95% of all sales with transparent, instant payments in HNYC tokens.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 gradient-sage rounded-lg flex items-center justify-center flex-shrink-0">
                    <Globe className="text-white h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Global Market Access</h4>
                    <p className="text-gray-600">Reach consumers worldwide through our blockchain-based marketplace.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Shield className="text-white h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Supply Chain Verification</h4>
                    <p className="text-gray-600">NFC tagging and blockchain tracking builds consumer trust and premium pricing.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <CheckSquare className="text-green-500 h-5 w-5" />
                    <span className="text-gray-700">Minimum 5 active hives (50-100 lbs production capacity)</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckSquare className="text-green-500 h-5 w-5" />
                    <span className="text-gray-700">Valid beekeeping license or certification</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckSquare className="text-green-500 h-5 w-5" />
                    <span className="text-gray-700">GPS coordinates for all hive locations</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckSquare className="text-green-500 h-5 w-5" />
                    <span className="text-gray-700">Monthly hive inspection reports and photos</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckSquare className="text-green-500 h-5 w-5" />
                    <span className="text-gray-700">Commitment to organic practices</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Application CTA */}
          <div className="space-y-8">
            <Card className="bg-gradient-to-br from-honey-50 to-sage-50">
              <CardHeader className="text-center">
                <CardTitle className="font-inter font-bold text-3xl text-gray-800">
                  Ready to Get Started?
                </CardTitle>
                <p className="text-gray-600 mt-4">
                  Join our network of verified beekeepers and start earning with transparent, blockchain-based transactions.
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="text-6xl font-bold text-honey-600 mb-2">95%</div>
                  <div className="text-gray-700 font-semibold">Revenue Share</div>
                  <div className="text-sm text-gray-600">Industry-leading compensation</div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-sage-600">127</div>
                    <div className="text-gray-600 text-sm">Active Farms</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-honey-600">$2.3M</div>
                    <div className="text-gray-600 text-sm">Farmer Earnings</div>
                  </div>
                </div>

                <Link href="/apply">
                  <Button className="w-full gradient-sage text-white py-4 text-lg hover:shadow-lg transition-all">
                    <i className="fas fa-paper-plane mr-2"></i>
                    Apply as Beekeeper
                  </Button>
                </Link>

                <div className="text-center text-sm text-gray-600">
                  <p>
                    <strong>Application Review:</strong> Applications are typically reviewed within 3-5 business days.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-white rounded-xl p-4 shadow-md">
                <div className="text-xl font-bold text-honey-600">24h</div>
                <div className="text-gray-600 text-sm">Avg Response</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-md">
                <div className="text-xl font-bold text-sage-600">98%</div>
                <div className="text-gray-600 text-sm">Approval Rate</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-md">
                <div className="text-xl font-bold text-blue-600">4.9★</div>
                <div className="text-gray-600 text-sm">Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
