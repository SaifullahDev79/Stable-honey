import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Wifi, CheckCircle, Smartphone, Eye } from "lucide-react";

export default function SupplyChainTracking() {
  const [nfcScanned, setNfcScanned] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const { data: nfcData, refetch: scanNFC } = useQuery({
    queryKey: ["/api/nfc", "demo-tag-001"],
    enabled: false,
  });

  const handleNFCScan = async () => {
    setIsScanning(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate scan delay
      await scanNFC();
      setNfcScanned(true);
    } catch (error) {
      console.error("NFC scan failed:", error);
    } finally {
      setIsScanning(false);
    }
  };

  const trackingSteps = [
    {
      number: 1,
      title: "Hive Registration",
      description: "Each hive receives a unique number and GPS coordinates, linked to the beekeeper's Lot#.",
      color: "honey"
    },
    {
      number: 2,
      title: "Production Logging",
      description: "All honey production is logged in our clearing house with weight, grade, and harvest date.",
      color: "sage"
    },
    {
      number: 3,
      title: "NFC Tagging",
      description: "Each container receives an NFC tag linking to blockchain records and production data.",
      color: "blue"
    },
    {
      number: 4,
      title: "Consumer Verification",
      description: "Consumers scan NFC tags to view complete production history and authenticity proof.",
      color: "purple"
    }
  ];

  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="font-inter font-bold text-4xl">Supply Chain Transparency</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Every jar of honey is tracked from hive to consumer using blockchain technology and NFC verification.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Tracking Flow */}
          <div className="space-y-8">
            <div className="space-y-6">
              {trackingSteps.map((step) => (
                <div key={step.number} className="flex items-start space-x-4">
                  <div className={`w-12 h-12 ${
                    step.color === 'honey' ? 'gradient-honey' :
                    step.color === 'sage' ? 'gradient-sage' :
                    step.color === 'blue' ? 'bg-blue-500' :
                    'bg-purple-500'
                  } rounded-full flex items-center justify-center flex-shrink-0`}>
                    <span className="text-white font-bold">{step.number}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-white">{step.title}</h3>
                    <p className="text-gray-300 text-sm">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* NFC Scanning Demo */}
          <div className="space-y-8">
            <Card className="bg-gradient-to-br from-gray-800 to-gray-700 border-gray-600">
              <CardHeader>
                <CardTitle className="font-inter font-bold text-2xl text-center text-white">
                  NFC Verification Demo
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                {/* Mock Honey Jar */}
                <div className="relative mx-auto w-48 h-64 mb-6">
                  <img 
                    src="https://images.unsplash.com/photo-1587049633312-d628ae50a8ae?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=600" 
                    alt="Glass jar of golden honey with label" 
                    className="w-full h-full object-cover rounded-xl" 
                  />
                  
                  {/* NFC Tag */}
                  <div 
                    className="absolute top-4 right-4 w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center nfc-pulse cursor-pointer hover:bg-blue-600 transition-colors"
                    onClick={handleNFCScan}
                  >
                    <Wifi className="text-white h-6 w-6" />
                  </div>
                </div>

                <Button 
                  onClick={handleNFCScan}
                  disabled={isScanning}
                  className="gradient-honey text-white px-8 py-3 hover:shadow-lg transition-all"
                >
                  {isScanning ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Scanning...
                    </>
                  ) : (
                    <>
                      <Smartphone className="mr-2 h-4 w-4" />
                      Tap to Scan NFC
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Scan Results */}
            {nfcScanned && nfcData && (
              <Card className="bg-white text-gray-800 shadow-xl">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 text-green-600">
                      <CheckCircle className="h-8 w-8" />
                      <span className="font-semibold text-lg">Verified Authentic</span>
                    </div>

                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Farm</span>
                        <span className="font-medium">{nfcData.farmName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Lot Number</span>
                        <span className="font-medium text-honey-600">{nfcData.lotNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Harvest Date</span>
                        <span className="font-medium">{nfcData.harvestDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Hive Number</span>
                        <span className="font-medium">{nfcData.hiveNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Grade</span>
                        <Badge className="bg-sage-100 text-sage-700">{nfcData.grade}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Weight</span>
                        <span className="font-medium">{nfcData.weight}</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <Button variant="link" className="text-honey-600 p-0 h-auto">
                        <Eye className="mr-1 h-4 w-4" />
                        View full blockchain record
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
