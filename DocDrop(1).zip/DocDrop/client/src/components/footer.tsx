import { Link } from "wouter";
import { Facebook, Twitter, Github, MessageCircle } from "lucide-react";

export default function Footer() {
  const platformLinks = [
    { name: "Invest in Farms", href: "#invest" },
    { name: "Buy Honey", href: "#invest" },
    { name: "Become Beekeeper", href: "/apply" },
    { name: "Track Supply Chain", href: "#farms" },
  ];

  const resourceLinks = [
    { name: "Documentation", href: "#" },
    { name: "API Reference", href: "#" },
    { name: "Smart Contracts", href: "#" },
    { name: "White Paper", href: "#" },
  ];

  const supportLinks = [
    { name: "Help Center", href: "#" },
    { name: "Contact Us", href: "#" },
    { name: "Bug Reports", href: "#" },
    { name: "Feature Requests", href: "#" },
  ];

  const legalLinks = [
    { name: "Privacy Policy", href: "#" },
    { name: "Terms of Service", href: "#" },
    { name: "Cookie Policy", href: "#" },
  ];

  const socialLinks = [
    { 
      name: "Twitter", 
      href: "#", 
      icon: Twitter,
      hoverColor: "hover:bg-honey-500"
    },
    { 
      name: "Discord", 
      href: "#", 
      icon: MessageCircle,
      hoverColor: "hover:bg-honey-500"
    },
    { 
      name: "GitHub", 
      href: "#", 
      icon: Github,
      hoverColor: "hover:bg-honey-500"
    },
  ];

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-honey rounded-full flex items-center justify-center">
                <i className="fas fa-layer-group text-white text-lg"></i>
              </div>
              <span className="font-inter font-bold text-xl">HoneyCoin</span>
            </Link>
            <p className="text-gray-300">
              Building a sustainable future for beekeeping through blockchain technology and transparent supply chains.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.href}
                    className={`w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center ${social.hoverColor} transition-colors`}
                    aria-label={social.name}
                  >
                    <IconComponent className="text-white h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Platform */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Platform</h4>
            <ul className="space-y-2 text-gray-300">
              {platformLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-honey-400 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Resources</h4>
            <ul className="space-y-2 text-gray-300">
              {resourceLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-honey-400 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Support</h4>
            <ul className="space-y-2 text-gray-300">
              {supportLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-honey-400 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2024 HoneyCoin. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm text-gray-400">
              {legalLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="hover:text-honey-400 transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 pt-8 border-t border-gray-700">
          <div className="grid md:grid-cols-3 gap-6 text-center md:text-left">
            <div>
              <h5 className="font-semibold text-white mb-2">Environmental Impact</h5>
              <p className="text-gray-400 text-sm">
                Every HNYC token supports bee conservation and sustainable farming practices.
              </p>
            </div>
            <div>
              <h5 className="font-semibold text-white mb-2">Blockchain Verified</h5>
              <p className="text-gray-400 text-sm">
                Complete supply chain transparency from hive to consumer with NFC verification.
              </p>
            </div>
            <div>
              <h5 className="font-semibold text-white mb-2">Fair Trade</h5>
              <p className="text-gray-400 text-sm">
                95% of revenue goes directly to beekeepers, ensuring fair compensation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
