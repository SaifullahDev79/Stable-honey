import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/use-wallet";
import { apiRequest } from "@/lib/queryClient";
import { ShoppingCart, Sprout, Calculator, CheckCircle, Info } from "lucide-react";

export default function InvestmentOptions() {
  const { user } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [calculator, setCalculator] = useState({
    amount: 100,
    type: "direct"
  });

  const investmentMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/investments", data);
    },
    onSuccess: () => {
      toast({
        title: "Investment Successful",
        description: "Your investment has been processed successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
    },
    onError: (error) => {
      toast({
        title: "Investment Failed",
        description: error.message || "Failed to process investment",
        variant: "destructive",
      });
    },
  });

  const handleInvestment = async (type: "direct" | "hive") => {
    if (!user) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to invest.",
        variant: "destructive",
      });
      return;
    }

    const investmentData = {
      userId: user.id,
      investmentType: type,
      amount: calculator.amount,
      tokensExpected: type === "direct" ? calculator.amount : calculator.amount * 1.12,
      seasonEndDate: type === "hive" ? new Date(Date.now() + 12 * 7 * 24 * 60 * 60 * 1000) : null,
    };

    investmentMutation.mutate(investmentData);
  };

  const expectedTokens = calculator.type === "direct" 
    ? calculator.amount 
    : Math.round(calculator.amount * 1.12);
  
  const timeline = calculator.type === "direct" ? "Immediate" : "12 weeks";

  return (
    <section id="invest" className="py-20 bg-gradient-to-br from-honey-50 to-sage-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="font-inter font-bold text-4xl text-gray-800">Investment Options</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose how you want to participate in the honey economy. Direct honey purchases or seasonal hive investments with drip payouts.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Direct Honey Purchase */}
          <Card className="bg-white shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-2">
            <CardHeader className="text-center">
              <div className="w-16 h-16 gradient-honey rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingCart className="text-white h-8 w-8" />
              </div>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">
                Direct Honey Purchase
              </CardTitle>
              <p className="text-gray-600 mt-2">Buy HNYC tokens and redeem for physical honey delivery</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-honey-50 rounded-xl p-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-honey-700">1 HNYC Token</span>
                  <span className="text-2xl font-bold text-honey-800">$1.00</span>
                </div>
                <div className="text-sm text-honey-600 mt-1">= 1 lb Grade A Honey</div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">Instant redemption available</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">NFC verified authenticity</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">Choose specific farms</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">Pickup or delivery options</span>
                </div>
              </div>

              <Button 
                className="w-full gradient-honey text-white py-4 text-lg hover:shadow-lg transition-all"
                onClick={() => handleInvestment("direct")}
                disabled={investmentMutation.isPending}
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Buy Honey Tokens
              </Button>
            </CardContent>
          </Card>

          {/* Hive Investment */}
          <Card className="bg-white shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-2 border-2 border-sage-200">
            <CardHeader className="text-center">
              <div className="w-16 h-16 gradient-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Sprout className="text-white h-8 w-8" />
              </div>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">
                Hive Investment
              </CardTitle>
              <p className="text-gray-600 mt-2">Invest in seasonal production with drip payouts over time</p>
              <Badge className="bg-sage-100 text-sage-700 mt-2">
                Popular Choice
              </Badge>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-sage-50 rounded-xl p-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-sage-700">Minimum Investment</span>
                  <span className="text-2xl font-bold text-sage-800">$100</span>
                </div>
                <div className="text-sm text-sage-600 mt-1">Expected: 105-120 HNYC over season</div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">5-20% seasonal returns</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">Weekly drip payouts</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 h-5 w-5" />
                  <span className="text-gray-700">Real-time hive monitoring</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Info className="text-amber-500 h-5 w-5" />
                  <span className="text-gray-700">Early exit penalty: 20%</span>
                </div>
              </div>

              <Button 
                className="w-full gradient-sage text-white py-4 text-lg hover:shadow-lg transition-all"
                onClick={() => handleInvestment("hive")}
                disabled={investmentMutation.isPending}
              >
                <Sprout className="mr-2 h-5 w-5" />
                Start Hive Investment
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Investment Calculator */}
        <Card className="mt-12 bg-white shadow-lg">
          <CardHeader>
            <CardTitle className="font-inter font-bold text-2xl text-gray-800 text-center">
              Investment Calculator
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="amount">Investment Amount (USDC)</Label>
                  <Input 
                    id="amount"
                    type="number"
                    value={calculator.amount}
                    onChange={(e) => setCalculator(prev => ({ ...prev, amount: parseInt(e.target.value) || 0 }))}
                    placeholder="100"
                  />
                </div>
                
                <div>
                  <Label htmlFor="type">Investment Type</Label>
                  <Select value={calculator.type} onValueChange={(value) => setCalculator(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="direct">Direct Purchase</SelectItem>
                      <SelectItem value="hive">Hive Investment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-honey-50 rounded-xl p-4">
                  <div className="text-honey-600 text-sm font-medium">Expected Tokens</div>
                  <div className="text-2xl font-bold text-honey-700">{expectedTokens} HNYC</div>
                </div>
                
                <div className="bg-sage-50 rounded-xl p-4">
                  <div className="text-sage-600 text-sm font-medium">Honey Equivalent</div>
                  <div className="text-2xl font-bold text-sage-700">{expectedTokens} lbs</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="text-gray-600 text-sm font-medium">Timeline</div>
                  <div className="text-xl font-bold text-gray-700">{timeline}</div>
                </div>
                
                <Button 
                  className="w-full gradient-honey text-white py-3 hover:shadow-lg transition-all"
                  onClick={() => handleInvestment(calculator.type as "direct" | "hive")}
                  disabled={investmentMutation.isPending}
                >
                  <Calculator className="mr-2 h-4 w-4" />
                  {investmentMutation.isPending ? "Processing..." : "Proceed with Investment"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
