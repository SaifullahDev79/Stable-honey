import { useQuery } from "@tanstack/react-query";
import NavigationHeader from "@/components/navigation-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Sprout, Coins, Package, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { user } = useWallet();

  const { data: investments, isLoading: investmentsLoading } = useQuery({
    queryKey: ["/api/investments/user", user?.id],
    enabled: !!user?.id,
  });

  const { data: redemptions, isLoading: redemptionsLoading } = useQuery({
    queryKey: ["/api/redemptions/user", user?.id],
    enabled: !!user?.id,
  });

  const { data: beekeeper } = useQuery({
    queryKey: ["/api/beekeepers/user", user?.id],
    enabled: !!user?.id,
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Connect Your Wallet</h1>
              <p className="text-gray-600">Please connect your wallet to access your dashboard.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="font-inter font-bold text-3xl text-gray-800">Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, {user.walletAddress.slice(0, 6)}...{user.walletAddress.slice(-4)}</p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Investments</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-sage-600">
                {investments?.length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">HNYC Balance</CardTitle>
              <Coins className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-honey-600">
                1,250 HNYC
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Redemptions</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {redemptions?.length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">User Type</CardTitle>
              <Sprout className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <Badge variant={beekeeper ? "default" : "secondary"}>
                {beekeeper ? "Beekeeper" : "Consumer"}
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="investments" className="space-y-6">
          <TabsList>
            <TabsTrigger value="investments">Investments</TabsTrigger>
            <TabsTrigger value="redemptions">Redemptions</TabsTrigger>
            {beekeeper && <TabsTrigger value="farming">Farming</TabsTrigger>}
          </TabsList>

          <TabsContent value="investments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Your Investments</CardTitle>
              </CardHeader>
              <CardContent>
                {investmentsLoading ? (
                  <div className="text-center py-8">Loading investments...</div>
                ) : investments?.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No investments yet</p>
                    <Button className="gradient-honey text-white">
                      Start Investing
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {investments?.map((investment: any) => (
                      <div key={investment.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-gray-800">
                              {investment.investmentType === 'direct' ? 'Direct Honey Purchase' : 'Hive Investment'}
                            </h3>
                            <p className="text-sm text-gray-600">Amount: ${investment.amount} USDC</p>
                            <p className="text-sm text-gray-600">Expected: {investment.tokensExpected} HNYC</p>
                          </div>
                          <Badge variant={investment.isActive ? "default" : "secondary"}>
                            {investment.isActive ? "Active" : "Completed"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="redemptions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Honey Redemptions</CardTitle>
              </CardHeader>
              <CardContent>
                {redemptionsLoading ? (
                  <div className="text-center py-8">Loading redemptions...</div>
                ) : redemptions?.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No redemptions yet</p>
                    <Button className="gradient-sage text-white">
                      Redeem Honey
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {redemptions?.map((redemption: any) => (
                      <div key={redemption.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-gray-800">Honey Redemption</h3>
                            <p className="text-sm text-gray-600">Tokens Used: {redemption.tokensUsed} HNYC</p>
                            <p className="text-sm text-gray-600">Method: {redemption.deliveryMethod}</p>
                          </div>
                          <Badge variant={redemption.isCompleted ? "default" : "secondary"}>
                            {redemption.isCompleted ? "Completed" : "Processing"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {beekeeper && (
            <TabsContent value="farming" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Farm Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">Farm Details</h3>
                      <p className="text-sm text-gray-600">Farm: {beekeeper.farmName}</p>
                      <p className="text-sm text-gray-600">Lot#: {beekeeper.lotNumber}</p>
                      <p className="text-sm text-gray-600">Hives: {beekeeper.totalHives}</p>
                      <p className="text-sm text-gray-600">Experience: {beekeeper.yearsExperience} years</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">Status</h3>
                      <Badge variant={beekeeper.isApproved ? "default" : "secondary"}>
                        {beekeeper.isApproved ? "Approved" : "Pending Approval"}
                      </Badge>
                      {!beekeeper.isApproved && (
                        <p className="text-sm text-gray-600 mt-2">
                          Your application is under review. We'll notify you once approved.
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}
