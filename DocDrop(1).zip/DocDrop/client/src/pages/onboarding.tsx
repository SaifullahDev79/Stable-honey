import NavigationHeader from "@/components/navigation-header";
import BeekeeperOnboarding from "@/components/beekeeper-onboarding";
import Footer from "@/components/footer";

export default function OnboardingPage() {
  return (
    <div className="font-sans bg-gray-50">
      <NavigationHeader />
      <BeekeeperOnboarding />
      <Footer />
    </div>
  );
}