import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import NavigationHeader from "@/components/navigation-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/use-wallet";
import { apiRequest } from "@/lib/queryClient";
import { AlertCircle, Upload } from "lucide-react";

export default function BeekeeperApplication() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useWallet();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    farmName: "",
    yearsExperience: "",
    totalHives: "",
    gpsLatitude: "",
    gpsLongitude: "",
    certifications: [] as string[],
    agreeToTerms: false,
  });

  const applicationMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/beekeepers", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your beekeeper application has been submitted successfully. We'll review it within 3-5 business days.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/beekeepers/user", user?.id] });
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Application Failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet first.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.agreeToTerms) {
      toast({
        title: "Terms Required",
        description: "Please agree to the terms and conditions.",
        variant: "destructive",
      });
      return;
    }

    const applicationData = {
      userId: user.id,
      firstName: formData.firstName,
      lastName: formData.lastName,
      farmName: formData.farmName,
      yearsExperience: parseInt(formData.yearsExperience),
      totalHives: parseInt(formData.totalHives),
      gpsLatitude: formData.gpsLatitude,
      gpsLongitude: formData.gpsLongitude,
      certifications: formData.certifications,
    };

    applicationMutation.mutate(applicationData);
  };

  const handleCertificationChange = (certification: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      certifications: checked
        ? [...prev.certifications, certification]
        : prev.certifications.filter(c => c !== certification)
    }));
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Connect Your Wallet</h1>
              <p className="text-gray-600">Please connect your wallet to apply as a beekeeper.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 text-center">
          <h1 className="font-inter font-bold text-4xl text-gray-800">Join Our Beekeeper Network</h1>
          <p className="text-xl text-gray-600 mt-4 max-w-3xl mx-auto">
            Become a verified beekeeper and connect directly with consumers. Earn 95% of sales revenue while we handle the platform and logistics.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Benefits & Requirements */}
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Benefits of Joining</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 gradient-honey rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold">95%</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Revenue Share</h4>
                    <p className="text-gray-600">Keep 95% of all sales with transparent, instant payments in HNYC tokens.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 gradient-sage rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-globe text-white text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Global Market Access</h4>
                    <p className="text-gray-600">Reach consumers worldwide through our blockchain-based marketplace.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-shield-alt text-white text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Supply Chain Verification</h4>
                    <p className="text-gray-600">NFC tagging and blockchain tracking builds consumer trust and premium pricing.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-check-square text-green-500"></i>
                    <span className="text-gray-700">Minimum 5 active hives (50-100 lbs production capacity)</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-check-square text-green-500"></i>
                    <span className="text-gray-700">Valid beekeeping license or certification</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-check-square text-green-500"></i>
                    <span className="text-gray-700">GPS coordinates for all hive locations</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-check-square text-green-500"></i>
                    <span className="text-gray-700">Monthly hive inspection reports and photos</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-check-square text-green-500"></i>
                    <span className="text-gray-700">Commitment to organic practices</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Application Form */}
          <Card className="bg-gradient-to-br from-honey-50 to-sage-50">
            <CardHeader>
              <CardTitle className="font-inter font-bold text-2xl text-gray-800">Beekeeper Application</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                      placeholder="John"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                      placeholder="Doe"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="farmName">Farm/Business Name *</Label>
                  <Input
                    id="farmName"
                    value={formData.farmName}
                    onChange={(e) => setFormData(prev => ({ ...prev, farmName: e.target.value }))}
                    placeholder="Meadowbrook Apiary"
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="yearsExperience">Years of Experience *</Label>
                    <Select value={formData.yearsExperience} onValueChange={(value) => setFormData(prev => ({ ...prev, yearsExperience: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select experience" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1-2 years</SelectItem>
                        <SelectItem value="3">3-5 years</SelectItem>
                        <SelectItem value="6">6-10 years</SelectItem>
                        <SelectItem value="10">10+ years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="totalHives">Number of Hives *</Label>
                    <Input
                      id="totalHives"
                      type="number"
                      value={formData.totalHives}
                      onChange={(e) => setFormData(prev => ({ ...prev, totalHives: e.target.value }))}
                      placeholder="12"
                      min="5"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label>GPS Coordinates (Primary Location) *</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      value={formData.gpsLatitude}
                      onChange={(e) => setFormData(prev => ({ ...prev, gpsLatitude: e.target.value }))}
                      placeholder="40.7589"
                      required
                    />
                    <Input
                      value={formData.gpsLongitude}
                      onChange={(e) => setFormData(prev => ({ ...prev, gpsLongitude: e.target.value }))}
                      placeholder="-73.9851"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label>Certifications</Label>
                  <div className="space-y-2 mt-2">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="organic"
                        checked={formData.certifications.includes("organic")}
                        onCheckedChange={(checked) => handleCertificationChange("organic", !!checked)}
                      />
                      <Label htmlFor="organic">Organic Certification</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="license"
                        checked={formData.certifications.includes("license")}
                        onCheckedChange={(checked) => handleCertificationChange("license", !!checked)}
                      />
                      <Label htmlFor="license">State Beekeeping License</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="nhb"
                        checked={formData.certifications.includes("nhb")}
                        onCheckedChange={(checked) => handleCertificationChange("nhb", !!checked)}
                      />
                      <Label htmlFor="nhb">National Honey Board Member</Label>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Upload Hive Photos *</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-honey-400 transition-colors cursor-pointer mt-2">
                    <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-gray-600">Click to upload or drag and drop</p>
                    <p className="text-sm text-gray-500">PNG, JPG up to 10MB each</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="terms"
                    checked={formData.agreeToTerms}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, agreeToTerms: !!checked }))}
                  />
                  <Label htmlFor="terms" className="text-sm">
                    I agree to the Terms of Service and Privacy Policy. I commit to providing monthly hive inspections and maintaining organic practices.
                  </Label>
                </div>

                <Button 
                  type="submit" 
                  className="w-full gradient-sage text-white py-4 text-lg"
                  disabled={applicationMutation.isPending}
                >
                  {applicationMutation.isPending ? (
                    "Submitting Application..."
                  ) : (
                    <>
                      <i className="fas fa-paper-plane mr-2"></i>
                      Submit Application
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-6 p-4 bg-blue-50 rounded-xl">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="text-blue-500 mt-0.5 h-5 w-5" />
                  <div className="text-sm text-blue-800">
                    <strong>Application Review:</strong> Applications are typically reviewed within 3-5 business days. You'll receive an email notification once your application status changes.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
