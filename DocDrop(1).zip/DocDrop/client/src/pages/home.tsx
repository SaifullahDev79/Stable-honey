import NavigationHeader from "@/components/navigation-header";
import HeroSection from "@/components/hero-section";
import InteractiveFarmMap from "@/components/interactive-farm-map";
import InvestmentOptions from "@/components/investment-options";
import SupplyChainTracking from "@/components/supply-chain-tracking";
import TokenomicsSection from "@/components/tokenomics-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="font-sans bg-gray-50">
      <NavigationHeader />
      <HeroSection />
      <InteractiveFarmMap />
      <InvestmentOptions />
      <SupplyChainTracking />
      <TokenomicsSection />
      <Footer />
    </div>
  );
}
