import { useState, useEffect, createContext, useContext, ReactNode } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface WalletContextType {
  user: User | null;
  isConnected: boolean;
  isLoading: boolean;
  connectWallet: (walletAddress: string) => Promise<void>;
  disconnectWallet: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

interface WalletProviderProps {
  children: ReactNode;
}

export function WalletProvider({ children }: WalletProviderProps) {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const queryClient = useQueryClient();

  // Load wallet address from localStorage on mount
  useEffect(() => {
    const savedAddress = localStorage.getItem("honeycoin_wallet");
    if (savedAddress) {
      setWalletAddress(savedAddress);
      setIsConnected(true);
    }
  }, []);

  // Query user data when wallet is connected
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/users/wallet", walletAddress],
    enabled: !!walletAddress && isConnected,
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (userData: { walletAddress: string; userType: string }) => {
      const response = await apiRequest("POST", "/api/users", userData);
      return response.json();
    },
    onSuccess: (userData) => {
      queryClient.setQueryData(["/api/users/wallet", walletAddress], userData);
    },
  });

  const connectWallet = async (address: string) => {
    try {
      setWalletAddress(address);
      setIsConnected(true);
      localStorage.setItem("honeycoin_wallet", address);

      // Try to get existing user, if not found create new one
      try {
        const response = await fetch(`/api/users/wallet/${address}`);
        if (!response.ok) {
          // User doesn't exist, create new one
          await createUserMutation.mutateAsync({
            walletAddress: address,
            userType: "consumer"
          });
        }
      } catch (error) {
        console.error("Error handling user:", error);
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error);
      throw error;
    }
  };

  const disconnectWallet = () => {
    setWalletAddress(null);
    setIsConnected(false);
    localStorage.removeItem("honeycoin_wallet");
    queryClient.removeQueries({ queryKey: ["/api/users/wallet"] });
  };

  const value: WalletContextType = {
    user: user || null,
    isConnected,
    isLoading,
    connectWallet,
    disconnectWallet,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
