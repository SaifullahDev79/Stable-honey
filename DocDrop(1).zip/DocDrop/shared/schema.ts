import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletAddress: text("wallet_address").notNull().unique(),
  email: text("email"),
  userType: text("user_type").notNull().default("consumer"), // consumer, beekeeper
  createdAt: timestamp("created_at").defaultNow(),
});

export const beekeepers = pgTable("beekeepers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  farmName: text("farm_name").notNull(),
  yearsExperience: integer("years_experience").notNull(),
  totalHives: integer("total_hives").notNull(),
  lotNumber: text("lot_number").unique().notNull(),
  gpsLatitude: decimal("gps_latitude", { precision: 10, scale: 8 }).notNull(),
  gpsLongitude: decimal("gps_longitude", { precision: 11, scale: 8 }).notNull(),
  certifications: jsonb("certifications").default([]),
  isApproved: boolean("is_approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const hives = pgTable("hives", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  beekeeperId: varchar("beekeeper_id").references(() => beekeepers.id).notNull(),
  hiveNumber: text("hive_number").notNull(),
  productionCapacity: integer("production_capacity").notNull(), // in lbs
  currentProduction: integer("current_production").default(0),
  isActive: boolean("is_active").default(true),
  lastInspection: timestamp("last_inspection"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const honeyInventory = pgTable("honey_inventory", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  hiveId: varchar("hive_id").references(() => hives.id).notNull(),
  weight: decimal("weight", { precision: 8, scale: 2 }).notNull(),
  grade: text("grade").notNull(), // Grade A, Grade B, etc.
  harvestDate: timestamp("harvest_date").notNull(),
  nfcTagId: text("nfc_tag_id").unique(),
  isRedeemed: boolean("is_redeemed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const investments = pgTable("investments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  beekeeperId: varchar("beekeeper_id").references(() => beekeepers.id),
  investmentType: text("investment_type").notNull(), // direct, hive
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  tokensExpected: decimal("tokens_expected", { precision: 10, scale: 2 }).notNull(),
  tokensReceived: decimal("tokens_received", { precision: 10, scale: 2 }).default("0"),
  seasonEndDate: timestamp("season_end_date"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tokenTransactions = pgTable("token_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  transactionType: text("transaction_type").notNull(), // mint, burn, transfer
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  fromAddress: text("from_address"),
  toAddress: text("to_address"),
  transactionHash: text("transaction_hash"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const redemptions = pgTable("redemptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  inventoryId: varchar("inventory_id").references(() => honeyInventory.id).notNull(),
  tokensUsed: decimal("tokens_used", { precision: 10, scale: 2 }).notNull(),
  deliveryMethod: text("delivery_method").notNull(), // pickup, mail
  deliveryAddress: text("delivery_address"),
  isCompleted: boolean("is_completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  investments: many(investments),
  tokenTransactions: many(tokenTransactions),
  redemptions: many(redemptions),
}));

export const beekeepersRelations = relations(beekeepers, ({ one, many }) => ({
  user: one(users, { fields: [beekeepers.userId], references: [users.id] }),
  hives: many(hives),
  investments: many(investments),
}));

export const hivesRelations = relations(hives, ({ one, many }) => ({
  beekeeper: one(beekeepers, { fields: [hives.beekeeperId], references: [beekeepers.id] }),
  inventory: many(honeyInventory),
}));

export const honeyInventoryRelations = relations(honeyInventory, ({ one, many }) => ({
  hive: one(hives, { fields: [honeyInventory.hiveId], references: [hives.id] }),
  redemptions: many(redemptions),
}));

export const investmentsRelations = relations(investments, ({ one }) => ({
  user: one(users, { fields: [investments.userId], references: [users.id] }),
  beekeeper: one(beekeepers, { fields: [investments.beekeeperId], references: [beekeepers.id] }),
}));

export const tokenTransactionsRelations = relations(tokenTransactions, ({ one }) => ({
  user: one(users, { fields: [tokenTransactions.userId], references: [users.id] }),
}));

export const redemptionsRelations = relations(redemptions, ({ one }) => ({
  user: one(users, { fields: [redemptions.userId], references: [users.id] }),
  inventory: one(honeyInventory, { fields: [redemptions.inventoryId], references: [honeyInventory.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertBeekeeperSchema = createInsertSchema(beekeepers).omit({
  id: true,
  createdAt: true,
  lotNumber: true,
  isApproved: true,
});

export const insertHiveSchema = createInsertSchema(hives).omit({
  id: true,
  createdAt: true,
});

export const insertInvestmentSchema = createInsertSchema(investments).omit({
  id: true,
  createdAt: true,
});

export const insertRedemptionSchema = createInsertSchema(redemptions).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Beekeeper = typeof beekeepers.$inferSelect;
export type InsertBeekeeper = z.infer<typeof insertBeekeeperSchema>;

export type Hive = typeof hives.$inferSelect;
export type InsertHive = z.infer<typeof insertHiveSchema>;

export type HoneyInventory = typeof honeyInventory.$inferSelect;
export type Investment = typeof investments.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;

export type TokenTransaction = typeof tokenTransactions.$inferSelect;
export type Redemption = typeof redemptions.$inferSelect;
export type InsertRedemption = z.infer<typeof insertRedemptionSchema>;
